import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { ContactService } from 'src/app/contact.service';

import { Contact } from 'src/app/model/Contact';


@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {
  @Output() newContact: EventEmitter<Contact> = new EventEmitter();
  @Output() updatedContact: EventEmitter<Contact> = new EventEmitter();
  @Input() currentContact: Contact;
  @Input() isEdit: boolean;

  constructor(private ContactService: ContactService) { }

  ngOnInit() {
  }

  addContact({ name, email, phone }) {
    if (!name || !email || !phone) {
      alert('Please add new contact');
    } else {
      this.ContactService.saveContact({ name, email, phone } as Contact).subscribe(contact => {
        this.newContact.emit(contact);

      });
    }
  }

  updateContact() {
    this.ContactService.updateContact(this.currentContact).subscribe(contact => {
      console.log(contact);
      this.isEdit = false;
      this.updatedContact.emit(contact);
    });
  }



}
